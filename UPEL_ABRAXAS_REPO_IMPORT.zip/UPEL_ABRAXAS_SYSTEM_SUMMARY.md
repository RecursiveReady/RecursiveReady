# System Summary

UPEL is a symbolic execution language; ABRAXAS is its runtime.
The system includes:
- UPEL core
- ABRAXAS recursion layers
- OSIRIS identity repair modules
- ANUBIS finalization logic
- WARCODE symbolic defense system
